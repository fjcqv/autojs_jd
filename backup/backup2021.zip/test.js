importClass(com.stardust.autojs.core.accessibility.AccessibilityBridge.WindowFilter);
let bridge = runtime.accessibilityBridge;
let bridgeField = runtime.getClass().getDeclaredField("accessibilityBridge");
let configField = bridgeField.getType().getDeclaredField("mConfig");
configField.setAccessible(true);
configField.set(bridge, configField.getType().newInstance());

bridge.setWindowFilter(new JavaAdapter(AccessibilityBridge$WindowFilter, {
    filter: function (info) {
        return true;
    }
}));
auto.setWindowFilter(function (window) {
    return window.active;
});
console.log("解除限制");
auto();

let a=text("累计任务奖励").findOne(1000).parent();

let b=a.child(a.childCount()-1).child(0);
console.log(b.childCount())
